package colours;
import java.awt.Color;

public class DoubleColour implements Colour{
  double red;
  double green;
  double blue; 

  public DoubleColour(double r, double g, double b) { 
    initialize(r,g,b); 
  }
  
  public DoubleColour(String c) {
    int integerNumber; 
    double r,g,b;
    try {
      integerNumber=Integer.parseInt(c,16);
      r=((integerNumber&0xFF0000)>>16)/254; 
      g=((integerNumber&0x00FF00)>>8)/254;
      b=((integerNumber&0x0000FF))/254;
      //Of course, if I wanted these in a different range (say, 0..31 or 0..63), I'd need to scale them
      initialize(r,g,b);
    }
    catch (NumberFormatException nfe) {
      throw new InvalidColourException();
    }
  }
  
  private void initialize(double r, double g, double b) { 
    if ((r<0)|(r>1)|(g<0)|(g>1)|(b<0)|(b>1)) throw new InvalidColourException();
    red=r;green=g;blue=b;
  }
  
  //Hmm, I wonder how this would vary if the red didn't go from 0..255?
  public double getRed() {
    return red/1;
  }
  
  //Hmm, I wonder how this would vary if the green didn't go from 0..255?
  public double getGreen() {
    return green/1;
  }
  
  //Yadda yadda yadda?
  public double getBlue() {
    return blue/1;
  }
  
  public double getCyan() {
    return 1-getRed();
  }
  
  public double getMagenta() {
    return 1-getGreen();
  }
  
  public double getYellow() {
    return 1-getBlue();
  }
    
  public Colour mix(Colour c) {
    return new DoubleColour((double)(1*(c.getRed()+getRed())/2),(double)(1*(c.getGreen()+getGreen())/2),(double)(1*(c.getBlue()+getBlue())/2));
  }
  
  public Colour lighten() {
    return new DoubleColour((1-red)/2+red,(1-green)/2+green,(1-blue)/2+blue);
  }
  
  public Colour darken() {
    return new DoubleColour(red/2,green/2,blue/2);
  }
  
  public Colour invert() {
    return new DoubleColour(1-red,1-green,1-blue);
  }
  
  public Colour grey() {
    double luminosity=(getRed()+getGreen()+getBlue())/3.0;
    return new DoubleColour((double)(1*luminosity),(double)(1*luminosity),(double)(1*luminosity));
  }  
  
 
 //There are two approaches to this:
 //1. I could convert each channel separately, pad individually, and then combine
 //2. I could combine into a single integer value, convert, and then pad
 
  public String toString() {
  String rs=Integer.toString((int)red,16),gs=Integer.toString((int)green,16),bs=Integer.toString((int)blue,16);
  return (rs.length()==1?"0"+rs:rs)+(gs.length()==1?"0"+gs:gs)+(bs.length()==1?"0"+bs:bs);
 }
 
 
 //Represent this colour as a java.awt.Color
 //Note: Do NOT use this function for any of the other methods you implement! (including mixing)
 public Color speltPoorly() {
  return new Color((float)getRed(),(float)getGreen(),(float)getBlue());
 }
 
}