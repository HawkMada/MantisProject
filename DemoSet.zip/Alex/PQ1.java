package priority;

import java.util.NoSuchElementException;

/* COSC 1P03
 * ASSIGNMENT #3
 * Name: Ajay Patel
 * Student #: 5660055
 *
 * The actual PQ, has a variety of methods that will make the PQ function, uses the function of having simple
 * //peekfirst/removefirst and then using the add function as a way to find the key and place it correctly in the queue
 */
/*This class represents an actual implementation of a Priority Queue.
 *In this case, it's a dynamically-allocated one.
 *Note that there are two overall approaches for implementing a priority queue.
 *Refer to the assignment sheet for explanations of both.
 */


public class LinkedPriorityQueue<E extends Prioritized<E>> implements PriorityQueue<E> {
  
  PQNode<E> front;
  
  public LinkedPriorityQueue() {
    front = null;
  }
  
  //The add function adds an item to the PQ.
  public void add(E item) {
    
    if (front == null){
      front = new PQNode<E>(item,null);
    }
    // when the front has no value,  just add the current movie to the front followed by nothing
    
    else if ((item).compareTo(front.item) < 0){
      front = new PQNode<E>(item,front);
    }   
    // this adds the movie to the front if its better than the current front, if the current item is better than the front,
    // it is added to the front 
    
    else {
      PQNode<E> best = front;
      PQNode<E> comp = front;
      while (best != null && ((item).compareTo(best.item) > 0)){
        comp = best;
        if(best.next != null) {
          best=best.next;
        }
        else         
        {break;}
      }
      comp.next=new PQNode<E> (item, comp.next);
    }
    //this adds the movie to its correct location, two new temporary values are created(best,comp), both holding the front of the
    // list, so a while loop runs while the best variable isnt empty, and when the values are greater than 0, it assigns best to comp, then
    // an if statement runs if the next value of best is empty, this assigns the next value of the best(front) to best
    // otherwise, there is a break, then comp.next is the new node with the current item, and itself
  }
  
  /*The removeFirst function removes the element with the highest priority
   *from the queue and returns it.
   *If more than one element in the PQ has the same priority, it returns
   *the highest-priority element that was added first.
   *Note: When an element has its priority changed, that counts as adding it fresh to the queue.
   *If this function is called when the PQ is empty, a NoSuchElementException is thrown.
   */
  public E removeFirst() {
    if (empty())
      throw new NoSuchElementException();
    E current=front.item;
    front=front.next;
    return current;
  }
  
  /*The peekFirst function is like the removeFirst function, except the PQ structure doesn't change.
   *i.e. the highest-priority element is returned, but isn't removed from the PQ.
   *If this function is called when the PQ is empty, a NoSuchElementException is thrown.
   */
  public E peekFirst() {
    if (empty())
      throw new NoSuchElementException();
    return front.item;
  }
  
  /*The updatePriority method locates an element (identified by its key), and assigns a new
   *priority to it.
   *If no element in the queue matches the provided key, a NoSuchElementException is thrown.
   */ // 
  public void updatePriority(String key, double newPriority) {
    PQNode<E> temp = front;
    PQNode<E> previous = front;
    PQNode<E> node = null;
    if(front != null && front.item.getKey().equals(key)) { //if the front isnt null, and the first item has the same key as the one submitted, it continues
      node = front;   // front is assigned to node
      front = front.next; // the next node after front is assigned to the front 
    }
    else{ //otherwise if the above doesnt occur,
      temp = temp.next;  // the value after temp is placed in temp
      while(temp != null) { // while it is not empty 
        if(temp.item.getKey().equals(key)) { // if the key is the same as the strings key
          node = temp; 
          previous.next = temp.next;
        }
        previous = temp;
        temp = temp.next;
      }
    }
    // if there is no node, then change the priority and add it
    if(node != null) { 
      node.item.changePriority(newPriority);
      this.add(node.item);
    }
    else{
      throw new NoSuchElementException();
    }
    //otherwise throw an exception
  }
  
  //This function returns true when the PQ is empty; false otherwise
  public boolean empty() {
    if (front==null){
      return true;
    }
    else {
      return false;
    }
  }
  
  //this function returns a string that checks if the front is empty, then the front is assigned to temp and a String
  // called queueStr is defined as empty
  // a do while loop concatenates the temporary item to a string, and breaks when there are no values left
  public String toString(){
    if(front == null) {
      return null;
    }
    PQNode<E> temp = front;
    String queueStr = "";
    
    do {
      queueStr = queueStr+ " \n" + temp.item.toString();
    }
    while(((temp = temp.next) != null));
    return queueStr;
  }
  
}